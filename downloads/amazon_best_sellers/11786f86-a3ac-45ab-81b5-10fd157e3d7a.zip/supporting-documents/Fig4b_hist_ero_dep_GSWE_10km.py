# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

dirname = os.path.dirname(__file__)


table = pd.read_csv(os.path.join("C:/Users/Lenovo/OneDrive - University of Exeter/02_Postdoc Exeter/01_Papers/Paper5_fieldwork/Paper_submission/Data_repository/GIS_analysis/RkmMigration.csv"))

bank_att = (table['Association with Qrock'])

fig = plt.figure(1, figsize=(12,6))
fig.subplots_adjust(hspace=-0.5)

# set all labels to Arial
plt.rcParams["font.family"] = "Arial"

ax2 = plt.subplot(1,1,1)
# ax2 = plt.subplot(2,1,2)


# compute ersosion and deposition along banks
ero_all = np.array(table['Erosion 10km Avg/Yr (m)'])
dep_all = np.array(table['Deposition 10km Avg/Yr (m)'])

# remove reaches that are free 
ero_att_L = ero_all[(bank_att=='Left')]

# remove reaches that are free 
ero_att_R = ero_all[(bank_att=='Right')]

ero_att = np.concatenate((ero_att_L,ero_att_R))

ero_unatt = ero_all[(bank_att=='Away') | (bank_att=='Transition')]

# remove reaches that are free 
dep_att_L = dep_all[(bank_att=='Left')]

# remove reaches that are free 
dep_att_R = dep_all[(bank_att=='Right')]

dep_att = np.concatenate((dep_att_L,dep_att_R))

dep_unatt = dep_all[(bank_att=='Away') | (bank_att=='Transition')]


bins1 = np.linspace(-5, 95, 21)


a = ax2.hist([ero_unatt,ero_att,dep_unatt,dep_att], bins1, alpha=0.8, color = ['red','lightcoral','navy','blue'], edgecolor = None,density=True)
ax2.set_xlabel('Mean erosion and deposition [m/yr]',fontsize = 13)
ax2.set_ylabel('Fraction of total reaches [-]',fontsize = 13)
ax2.legend(['E disassociated','D disassociated','E associated','D associated'],fontsize = 12,edgecolor=[1,1,1], loc = 'lower right')
ax2.set_xlim(0,50)
ax2.set_xticks(np.arange(2.5,50,5))
ax2.set_xticklabels(['0-5','5-10','10-15','15-20','20-25','25-30','30-35','35-40','40-45','45-50'])
ax2.set_ylim([0,0.17])

for i in range(5,55,5):
    ax2.plot([i,i],[0,0.18],linestyle='--', linewidth = 0.5, color = 'black')


plt.savefig(os.path.join(dirname,'Fig4b_hist_ero_dep_GSWE.png')) 