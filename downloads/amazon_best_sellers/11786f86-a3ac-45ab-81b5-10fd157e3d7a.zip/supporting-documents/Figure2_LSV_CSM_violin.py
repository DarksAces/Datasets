# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 09:44:09 2022

one@author: Muriel Brückner - Extracting shear vane and CSM data, process shear vane data, and plot as violin plot for both banks. 
    Two csv files required: Measurement_locations.csv for location details and CSM_measurements_test3.csv is CSM measurements. 
    In addition, loop over shear vane measurements saved under location ID. The legend is postprocessed in another program.
"""

# load packages
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

# dirname = os.path.dirname(__file__)

dirname = 'C:/Users/Lenovo/OneDrive - University of Exeter/02_Postdoc Exeter/01_Papers/Paper5_fieldwork/Paper_submission/Data_repository/Measurements/'
# define output_name of figure
fname = os.path.join(dirname, "Fig2_LSV_CSM_violin.png") # number is the percentage that is used for critical shear stress


# create subplot figure
figure = plt.figure(1, figsize=(12,11))
ax1 = plt.subplot(2,1,1)
ax2 = plt.subplot(2,1,2)
plt.rcParams["font.family"] = "Arial"


# read location data
labels = pd.read_csv(os.path.join(dirname,'Measurement_locations.csv')) # removed a few measurements that I could not find on map
river_km = -labels['river km']

# read CSM data
labelsCSM = pd.read_csv(os.path.join(dirname,'CSM_measurements_test3.csv'))

# allocate empty arrays
meanNB = np.ones([len(labels)])
meanNB[meanNB==1]=np.nan
mean_CSM_NB = np.ones(len(labels))
mean_CSM_NB[mean_CSM_NB==1]=np.nan
meanSB = np.ones([len(labels)])
meanSB[meanSB==1]=np.nan
mean_CSM_SB = np.ones(len(labels))
mean_CSM_SB[mean_CSM_SB==1]=np.nan

# loop over labels (Location ID) in csv files
for scen in range(0,len(labels)):
    
    # extract ID data and sediment classification (type)
    mat = labels.iloc[scen]
    name = mat['Location ID']
    type = mat['type']
    
    # loop over types of sediments
    if type == 'Floodplain deposits, bars':
        symbol = 1
    elif type == 'Floodplain deposits, banks':
        symbol = 5
    elif type == 'Pleistocene mud':
        symbol = 10
    elif type == 'Pleistocene mud, sand lenses':
        symbol = 20        
    elif type == 'Sandstone':
        symbol = 25        
    elif type == 'Red sandstone':
        symbol = 25         
    elif type == 'Pleistocene mud, desiccated':
        symbol = 10 
        
    # read shear vane data    
    data = pd.read_csv(os.path.join(dirname,"shear_measurements_LSV"+name+".csv"))  # cvs: read_csv

    data1 = data['conv.'] # final postprocessed data 
    data1 = data1.dropna()
    
    # separate into left (north) and right (south) bank    
    if symbol> 5: # at left bank
        violinparts = ax1.violinplot(data1, positions=[river_km[scen]], showmeans=True, widths = 5)    # south bank
    else: # at right bank
        violinparts = ax1.violinplot(data1, positions=[river_km[scen]-125], showmeans=True, widths = 5)   # north bank

    # define violin colors
    for pc in violinparts['bodies']:
        
        if symbol == 1:
            pc.set_facecolor('gray')
            pc.set_edgecolor('black')
        elif symbol ==5:
            pc.set_facecolor('blue')
            pc.set_edgecolor('black')     
        elif symbol ==10:
            pc.set_facecolor('orange')
            pc.set_edgecolor('black')   
        elif symbol ==20:
            pc.set_facecolor('yellow')
            pc.set_edgecolor('black')
        elif symbol ==25:
            pc.set_facecolor('red')
            pc.set_edgecolor('black')     
        elif symbol ==30:
            pc.set_facecolor('red')
            pc.set_edgecolor('black')
        elif symbol ==35:
            pc.set_facecolor('gray')
            pc.set_edgecolor('black')

        # transparency value for violins            
        pc.set_alpha(0.7)
        
    # define violin parameters        
    for partname in ('cbars','cmins','cmaxes','cmeans'):
        vp = violinparts[partname]
        vp.set_edgecolor('black')
        vp.set_linewidth(1)   
    
    # calculate means from shear vane data for both banks
    if symbol <=5:        
        meanNB[scen] = np.mean(data1)
    else:
        meanSB[scen] = np.mean(data1)
        
    
    # extract mean CSM data   
    kPaCSM = np.nan

    # at left bank
    if symbol> 5:

        if scen==0:
            tt=0
        if tt< len(labelsCSM):
            matCSM = labelsCSM.iloc[tt]
            nameCSM =matCSM['Location ID']
            if nameCSM == name:
                kPaCSM = matCSM['tau_crit']
                ax1.scatter(river_km[scen],kPaCSM*10, s=100, marker = 's',  c='black', edgecolor = 'white')
                tt+=1   
                mean_CSM_SB[scen] = kPaCSM
    else: # at right bank
        if scen==0:
            tt=0
        if tt< len(labelsCSM):
            matCSM = labelsCSM.iloc[tt]
            nameCSM =matCSM['Location ID']
            if nameCSM == name:
                kPaCSM = matCSM['tau_crit']
                ax1.scatter(river_km[scen]-125,kPaCSM*10, s=140, marker = 's', c='black', edgecolor = 'white')
                tt+=1   
                mean_CSM_NB[scen] = kPaCSM        

# plot vertical line for mean values
ax1.plot([-900,-715],[np.nanmean(meanNB),np.nanmean(meanNB)], linestyle = '--', color = 'red')
ax1.plot([-900,-715],[np.nanmean(mean_CSM_NB*10),np.nanmean(mean_CSM_NB*10)], linestyle = '--', color = 'darkgray')
ax1.plot([-715,-580],[np.nanmean(meanSB),np.nanmean(meanSB)], linestyle = '--', color = 'red')
ax1.plot([-715,-580],[np.nanmean(mean_CSM_SB*10),np.nanmean(mean_CSM_SB*10)], linestyle = '--', color = 'darkgray')
  
# define figure properties
ax1.plot([-715,-715],[220,0], color='gray')
# set axes properties
ax1.set_ylabel('Mean bank strength [kPa]',fontsize = 13, family = 'Arial')
ax1.set_xlabel('River km',fontsize = 13, family = 'Arial')
ax1.set_ylim([0,220])
ax1.set_xlim([-700,-590])
array = np.arange(600,850,25)
ax1.set_xticks(-array)
ax1.set_xticklabels(['600','625','650','675','700','600','625','650','675','700'],fontsize = 10, family = 'Arial')

# define labels x-axis
ax1.text(-630, -25, 'Downstream', style='normal', color='black', fontsize = 13, family = 'Arial')
ax1.text(-815   , -25, 'Upstream', style='normal', color='black',  fontsize = 13, family = 'Arial')

# define labels
ax1.text(-710, 205, 'Right bank', style='normal', color='black', fontsize = 14, family = 'Arial')
ax1.text(-820, 205, 'Left bank', style='normal', color='black',  fontsize = 14, family = 'Arial')

# define legend properties
leg = pd.DataFrame({'n1':[1,1,1,1,1,1], 'n2':[1,1,1,1,1,1], 'l':['Holocene deposits, bar','Holocene deposits, banks','Pleistocene mud','Pleistocene mud, sand lenses','Sandstone', 'CSM'], 'colors':['brown','green','orange','yellow','red','black']})

# remove invisible axis from plot
ax2.set_position([0.222,0.63,0.005,0.25])
ax2.set_axis_off()

# set colors of legend entries
colors = ['gray','blue','orange','yellow','red','black']
for i,c in enumerate(colors):
    x = leg['n1'][i]
    y = leg['n2'][i]
    l = leg['l'][i]
    ax2.scatter(x,y, s=10, label = l, c=c, marker = 's',edgecolor = 'black')

# plot mean value lines for legend  
ax2.plot([-1,-1.5],[0,0], linestyle = '--', color = 'red',label= 'Mean shear vane')
ax2.plot([-1,-1.5],[0,0], linestyle = '--', color = 'darkgray',label= 'Mean CSM')
ax2.legend(fontsize=13, loc = 'upper left',edgecolor = 'white')

# save figure
plt.savefig(fname) 

