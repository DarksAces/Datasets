# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

dirname = os.path.dirname(__file__)


table = pd.read_csv(os.path.join(dirname, 'RkmMigration.csv'))

bank_att = (table['Association with Qrock'])

right_bank_att = bank_att=='Right'
left_bank_att = bank_att=='Left'
unattached = bank_att=='Away'

fig = plt.figure(1, figsize=(8,4))
fig.subplots_adjust(hspace=-0.5)

# set all labels to Arial
plt.rcParams["font.family"] = "Arial"

ax1 = plt.subplot(2,1,1)
# ax2 = plt.subplot(2,1,2)

rkm = (table['10km Rkm'])


bins1 = np.linspace(0, 1600, 17)


# # compute number of reaches that are attached vs free  along each bank
no_L_att = rkm.loc[left_bank_att]
# # idx = left_bank_att==0
# # no_L_att.iloc[idx]=np.nan # reaches that are attached=1

no_R_att = rkm.loc[right_bank_att]
# # no_R_att.iloc[right_bank_att==0]=np.nan # reaches that are attached=1

no_unatt = rkm.loc[unattached]


ax1.hist([no_L_att,no_R_att,no_unatt], bins1, alpha=1, width=50,color = ['navy','orange','red'], edgecolor = None, stacked=True)#, density ='True')
ax1.set_xlabel('Distance from Manaus [km]',fontsize = 12)
ax1.set_ylabel('No. of 10-km reaches/100km',fontsize = 12)
ax1.set_xlim(-30,1580)
ax1.set_ylim([0,10])
ax1.set_xticks(np.arange(25,1600,100))
ax1.set_yticks(np.arange(4,22,4))
ax1.set_yticklabels(['2','4','6','8','10'])
ax1.set_xticklabels(['0-\n100','100-\n200','200-\n300','300-\n400','400-\n500','500-\n600','600-\n700','700-\n800','800-\n900','900-\n1000','1000-\n1100','1100-\n1200','1200-\n1300','1300-\n1400','1400-\n1500','1500-\n1600'])


ax1.legend(['associated LB','associated RB', 'disassociated'],fontsize = 12,edgecolor=[1,1,1],loc='center left', bbox_to_anchor=(0.5, -0.55))


plt.savefig(os.path.join(dirname, 'Fig4a_hist_ero_dep_GWSE_10km.png')) 