# Global plant climate envelopes

## Data

These data were generated as part of Harris et al. (2022) 'Strong phylogenetic signals in global plant bioclimatic envelopes', Global Ecology and Biogeography. The metadata were prepared by Claire Harris and Richard Reeve on 21/06/2022.

### Data Sources

Plant occurrence records from the Global Biodiversity Information Facility ([GBIF, 2019](https://www.gbif.org)) from 1901-2018. [CERA-20C](https://www.ecmwf.int/en/forecasts/datasets/reanalysis-datasets/cera-20c) and [Era-Interim](https://www.ecmwf.int/en/forecasts/datasets/reanalysis-datasets/era-interim) climate reconstructions 1901-2018 from the European Centre for Medium-Range Weather Forecasting ([ECMWF](https://www.ecmwf.int)). We used monthly means of daily means for most of the climate variables except for precipitation and solar radiation, which were monthly means of daily forecast accumulations.

### Aim

To produce a bioclimatic envelope for each species recorded in the Global Biodiversity Information Facility (GBIF) for the past century based on occurrence records and historical climate. Each envelope was adjusted for effort of collection using the Enhanced Vegetation Index from MODIS.

### Methodology

We extracted the entire history of plant occurrences from GBIF, which totals roughly 212 million individual records. The data were filtered for species with an accepted name in The Plant List ([TPL, 2013](http://www.theplantlist.org/)), in order to remove marine species and fossils, which left around 215,000 species and just over 100 million records. The data were additionally cleaned for the presence of 3,441 botanic garden locations with available GPS coordinates, taken from Botanic Gardens Conservation International ([BGCI, 2019](https://tools.bgci.org/garden_search.php)), to eliminate records erroneously georeferenced to the locations at which the collections are stored. A buffer of 0.02 decimal degrees was taken around each botanic garden and all points that lay within this area were excluded. The same procedure was performed for country centroids, which can be erroneously assigned to records during the georeferencing process if no locality information is available. We also explored filtering this data further for the top 100 recording institutions, excluding those likely to include garden or greenhouse observations. As we found comparable results, we retain the original data in the study. GBIF also makes no distinction between native and alien records in their data. However, as we are interested in the climate envelopes that these species could tolerate, rather than their native ranges, information from introductions to other climates is very valuable to this end as it indicates their survival in new environments.

We downloaded historical climate reconstructions from the ECMWF for two reanalysis datasets; CERA-20C and ERA-Interim ([Dee et al., 2011](https://dx.doi.org/10.1002/qj.828); [Laloyaux et al., 2018](https://dx.doi.org/10.1029/2018MS001273)). We used the aggregated monthly datasets made available through the ECMWF, which are means of these 3-hourly records, for 11 climatic variables including temperature, precipitation and solar radiation. We replaced the final 39 years (1979---2018) with the more spatially resolved ERA-Interim for the same variables to create a complete timeline for 1901---2018.

In order to correct for biases in plant occurrence data, we also utilised mean global-level Enhanced Vegetation Index (EVI) as a proxy of plant density across the period 2001 to 2015 ([Huete et al., 1999](https://modis.gsfc.nasa.gov/data/atbd/atbd_mod13.pdf)). The data were originally derived from NASA's Moderate Resolution Imaging Spectrometer (MODIS) dataset, with processing and gap filling in cloud cover performed by Gibson & Weiss (2015). We excluded Antarctica and all islands within the Arctic circle, including Greenland, due to poor data quality.

Using the approximately 215,000 plant species we obtained from GBIF and the climate reconstructions from ECMWF (and other sources), we extracted the plant bioclimatic envelopes using the timing and location of occurrences.

For extracting profiles from ERA-Interim and CERA-20C data, we assumed that each of the individual plants recorded in GBIF, or a parent in the case of annuals, would have been present at the site for at least one year prior to collection. Thus, for every  record available in the filtered GBIF database, we extracted each of the variables at the month and location in which they were recorded and the preceding 11 months as a profile of climates the species could survive in. We averaged across the 12 months for every record and for each climate variable, with the exception of temperature, for which we also calculated minimum and maximum values. We then binned all records per species into 1,000 bins for each climate variable to produce a set of plant bioclimatic envelope profiles, to which we could then apply a correction for bias in the underlying GBIF data.

Plant records available in GBIF suffer from extreme spatial and taxonomic biases. In particular, there is a concentration of higher recording effort in Western Europe, Eastern America and Australia; and recording is particularly low throughout the tropics, where there is the highest concentration of rare and endangered species. In order to control for such biases in the raw GBIF data, we performed several corrections to reduce bias in the corresponding plant species bioclimatic envelopes. The first was to recover the true abundance of plant species at different levels of climate variables. In order to do this, we weighted the binned species preference profiles by the ratio of global distribution of plant collections against a proxy of plant abundance, the Enhanced Vegetation Index (EVI), to reduce observation bias. EVI has improved sensitivity to regions of high plant biomass compared to the more commonly used Normalised Difference Vegetation Index (NDVI) ([Huete et al., 1999](https://modis.gsfc.nasa.gov/data/atbd/atbd_mod13.pdf)). Finally, to prepare the data for input into the phylogenetic models, we averaged across the climate bins, weighting by number of records, to get an overall value per species for each climate variable.

Please see associated paper for full details of methods and [code](https://doi.org/10.5281/zenodo.6452065).


### Dataset description

The data comprises a single csv file, containing the average value of the climate envelope per species for each of the following [ECMWF parameters](https://apps.ecmwf.int/codes/grib/param-db):

- tmin - Minimum temperature (K) derived from [t_2m](https://apps.ecmwf.int/codes/grib/param-db?id=500011)*

- tmax - Maximum temperature (K) derived from [t_2m](https://apps.ecmwf.int/codes/grib/param-db?id=500011)*

- tmean - Average temperature (K) derived from [t_2m](https://apps.ecmwf.int/codes/grib/param-db?id=500011)*

- trng - Temperature range (K) derived from [t_2m](https://apps.ecmwf.int/codes/grib/param-db?id=500011)*

- [stl1](https://apps.ecmwf.int/codes/grib/param-db?id=139) - Soil temperature level 1 (K)

- [stl2](https://apps.ecmwf.int/codes/grib/param-db?id=170) - Soil temperature level 2 (K)

- [stl3](https://apps.ecmwf.int/codes/grib/param-db?id=183) - Soil temperature level 3 (K)

- [stl4](https://apps.ecmwf.int/codes/grib/param-db?id=236) - Soil temperature level 4 (K)

- [swvl1](https://apps.ecmwf.int/codes/grib/param-db/?id=39) - Volumetric soil water layer 1 (m^3 m^-3)

- [swvl2](https://apps.ecmwf.int/codes/grib/param-db/?id=40) - Volumetric soil water layer 2 (m^3 m^-3)

- [swvl3](https://apps.ecmwf.int/codes/grib/param-db/?id=41) - Volumetric soil water layer 3 (m^3 m^-3)

- [swvl4](https://apps.ecmwf.int/codes/grib/param-db/?id=42) - Volumetric soil water layer 4 (m^3 m^-3)

- [ssr](https://apps.ecmwf.int/codes/grib/param-db?id=176) - Surface net solar radiation (J m^-2)

- [tp](https://apps.ecmwf.int/codes/grib/param-db?id=228) - Total precipitation (mm)

We also include a unique identifier for each species (SppID), taxonomic information for each species, including the phylum, class, order, family and genus, as well as the number of occurrence records that informed the envelope (numrecords). * All derived from [t_2m](https://apps.ecmwf.int/codes/grib/param-db?id=500011) - Temperature at 2m (K) - see Methodology, above, for further details.

### References

BGCI. (2019). GardenSearch online database. *Retrieved from https://tools.bgci.org/garden_search.php*

Dee, D. P. *et al.* (2011). The ERA-Interim reanalysis: Configuration and performance of the data assimilation system. *Quarterly Journal of the Royal Meteorological Society*, 137 (656), 553–597. *Retrieved from [doi:10.1002/qj.828](https://dx.doi.org/10.1002/qj.828)*

GBIF. (2019). Global Biodiversity Information Facility. *Retrieved from https://www.gbif.org*

Gibson, H., & Weiss, D. (2015). Oxford MAP EVI: Malaria Atlas Project Gap-Filled Enhanced Vegetation Index.

Huete, A., Justice, C., & van Leeuwen, W. (1999). MODIS Vegetation Index (MOD13) Algorithm Theoretical Basis Document, Version 3. Tucson, Arizona: University of Arizona. *Retrieved from https://modis.gsfc.nasa.gov/data/atbd/atbd_mod13.pdf*

Laloyaux, P. *et al.* (2018). CERA-20C: A Coupled Reanalysis of the Twentieth Century. *Journal of Advances in Modeling Earth Systems*, 10 (5), 1172–1195. *Retrieved from [doi:10.1029/2018MS001273](https://dx.doi.org/10.1029/2018MS001273)*

TPL. (2013). The Plant List Version 1.1. *Retrieved from http://www.theplantlist.org/*
