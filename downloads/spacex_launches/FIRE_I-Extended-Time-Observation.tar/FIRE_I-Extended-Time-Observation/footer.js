{
document.write('<br>');
document.write('<hr>');
document.write('<a href=\"http:\/\/www.nasa.gov\">');
document.write('<img src=\"/SCOOL/3dmeatball.gif\" align=\"left\" border=\"0\" alt=\"NASA Meatball Logo\"><\/a>');
document.write('<address>');
document.write('<small>');
document.write( "<I>Last Updated: <SCRIPT> document.write (document.lastModified); </SCRIPT></I>");
document.write('<br>Web Curator:  <a href=\"/people_html\/pkc.html\">P. Kay Costulis<\/a> (<a href=\"mailto:p.k.costulis\@larc.nasa.gov\">p.k.costulis\@larc.nasa.gov<\/a>)');
document.write('<br>');
document.write('Responsible NASA Official: Victor E. Delnore, FIRE Project Manager, Science Directorate');
document.write('<br>');
document.write('<\/small>');
document.write('<\/address>');

document.close();
}
